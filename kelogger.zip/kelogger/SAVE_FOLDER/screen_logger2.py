import time
import os
from datetime import datetime
from PIL import ImageGrab
import keyboard

SAVE_FOLDER = "screenshots"      
INTERVAL_SECONDS = 10                  
RUNNING = True

if not os.path.exists(SAVE_FOLDER):
    os.makedirs(SAVE_FOLDER)

print("Start")
print("\n")

def get_filename():
    now = datetime.now()
    return f"screenshot_{now.strftime('%Y-%m-%d_%H-%M-%S')}.png"  

try:
    while RUNNING:

        screenshot = ImageGrab.grab()
        filename = os.path.join(SAVE_FOLDER, get_filename())
        screenshot.save(filename, "PNG")
        print(f"Saved: {filename}")
        
        start = time.time()
        while time.time() - start < INTERVAL_SECONDS:
            if keyboard.is_pressed("esc"):
                RUNNING = False
                print("\nStop")
                break
            time.sleep(0.1) 

except KeyboardInterrupt:

    print("\nCtrl+C.") 

print(f"\nTotal No of Screenshots: {len(os.listdir(SAVE_FOLDER))}")
print("End of Program .")